package com.example.nflapp;

import android.support.v7.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {
}
