package com.example.nflapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private View root;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.main_root);
        setNFLBackground();
    }

    protected void setNFLBackground(){
        root.setBackgroundResource(R.drawable.nfl);
    }
}
